
def get_scene_props(scene):
    return scene.hb_cabinet

def get_object_props(obj):
    return obj.hb_cabinet